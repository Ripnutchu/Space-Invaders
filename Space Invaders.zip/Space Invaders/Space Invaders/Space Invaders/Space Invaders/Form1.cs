﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Space_Invaders
{
    public partial class Background : Form
    {
        int spawnTimer = 0;

        double a = 0;
        int points = 0;
        int cnt = 0;

        Random rand = new Random();
        Invader[] invaders;
        Bullet[] bullets;
        bool[] keyStates;
        public Bitmap invader;

        bool hasShot = false;
        bool gameOver = false;

        public Background()
        {
            InitializeComponent();
            invaders = new Invader[5];
            bullets = new Bullet[5];
            keyStates = new bool[91];
            invader = new Bitmap("inv.png");
            for (int i = 0; i < 5; i++)
            {
                invaders[i] = new Invader();
                bullets[i] = new Bullet();
                invaders[i].box.BackgroundImage = invader;
                invaders[i].box.BackgroundImageLayout = ImageLayout.Zoom;
                this.Controls.Add(invaders[i].box);
                this.Controls.Add(bullets[i].box);
            }
        }


        private void Player_LocationChanged(object sender, EventArgs e)
        {
            if (Player.Left + Player.Width > this.Width - 15) 
            {
                Player.Left = this.Width - Player.Width - 15;
            }
            else if (Player.Left < 0) 
            {
                Player.Left = 0;
            }
        }

        private void Background_KeyUp(object sender, KeyEventArgs e)
        {
            keyStates[(int)e.KeyCode] = false;
        }
        private void Background_KeyDown(object sender, KeyEventArgs e)
        {
            keyStates[(int)e.KeyCode] = true;
        }

        private void MakePictureBox() 
        {
            for (int i = 0; i < invaders.Count(); i++)
            {
                if (invaders[i].active == false)
                {
                    double x = rand.NextDouble() * 500;
                    int i_x = (int)Math.Truncate(x);
                    invaders[i].active = true;
                    invaders[i].box.Width = 50;
                    invaders[i].box.Height = 50;
                    invaders[i].box.Location = new Point(i_x, -50);
                    break;
                }
            }
        }

        public class Invader
        {
            public PictureBox box;

            public bool active;
            public Invader()
            {
                box = new PictureBox();
                box.Width = 0;
                box.Height = 0;
                active = false;
            }

            public void kill()
            {
                box.Width = 0;
                box.Height = 0;
                active = false;
            }
        }

        public class Bullet
        {
            public PictureBox box;
            public bool active;
            public Bullet()
            {
                box = new PictureBox();
                box.Width = 10;
                box.Height = 20;
                box.BackColor = Color.Transparent;
                active = false;
            }

            public void kill()
            {
                box.Width = 0;
                box.Height = 0;
                active = false;
            }

            public void make() 
            {
                box.Width = 10;
                box.Height = 20;
                box.BackColor = Color.Red;
                active = true;
            }
        }

        private void MakeBullet()
        {
            cnt %= 5;
            bullets[cnt].make();
            bullets[cnt].box.Location = new Point(Player.Left + Player.Width / 2 - 5, Player.Top - 20);
            cnt++;
        }

        private bool BBcoll(int x1, int y1, int w1, int h1, int x2, int y2, int w2, int h2)
        {

            int interLeft = Math.Max(x1, x2);
            int interRight = Math.Min(x1 + w1, x2 + w2);
            int interTop = Math.Max(y1, y2);
            int interBottom = Math.Min(y1 + h1, y2 + h2);
            if (interLeft < interRight && interTop < interBottom)
                return true;
            else return false;

        }

        private void TimerEvent(object sender, EventArgs e)
        {
            if (gameOver)
                return;
            spawnTimer++;
            if (spawnTimer >= 90)
            {
                MakePictureBox();
                spawnTimer = 0;
            }

            if (keyStates[(int)Keys.A] == true)
            {
                if (a >= 15) a = 15;
                else a /= 1.005;
                Player.Left -= Convert.ToInt32(a);
            }

            if (keyStates[(int)Keys.D] == true)
            {
                if (a >= 15) a = 15;
                else a += 5;
                Player.Left += Convert.ToInt32(a);
            }

            if (keyStates[(int)Keys.Left] == true)
            {
                if (a >= 15) a = 15;
                else a += 5;
                Player.Left -= Convert.ToInt32(a);
            }

            if (keyStates[(int)Keys.Right] == true)
            {
                if (a >= 15) a = 15;
                else a += 5;
                Player.Left += Convert.ToInt32(a);
            }
            if (keyStates[(int)Keys.Space] == true && hasShot == false)
            {
                hasShot = true;
                MakeBullet();
            }
            if (keyStates[(int)Keys.Space] == false)
                hasShot = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (gameOver)
                return;
            for (int i = 0; i < invaders.Count(); i++)
            {
                if (invaders[i].active == true) invaders[i].box.Top += 2;
                if (invaders[i].active == true && invaders[i].box.Bottom >= 550)
                {
                    gameOver = true;
                    Over.Visible = true;
                }
            }

            for (int i = 0; i < bullets.Count(); i++)
            {
                if (bullets[i].active == true) bullets[i].box.Top -= 5;
                if (bullets[i].active == true && bullets[i].box.Top <= 50) bullets[i].kill();
            }
            for (int j = 0; j < bullets.Count(); j++)
            {
                if (bullets[j].active == false)
                    continue;
                for (int i = 0; i < invaders.Count(); i++)
                {
                    if (invaders[i].active == false)
                        continue;
                    if (BBcoll(bullets[j].box.Left, bullets[j].box.Top, bullets[j].box.Width, bullets[j].box.Height, invaders[i].box.Left, invaders[i].box.Top, invaders[i].box.Width, invaders[i].box.Height) == true)
                    { 
                        invaders[i].kill();
                        bullets[j].kill();
                        points += 100;
                        Counter.Text = "Points: " + points;
                    }
                }
            }

            for (int i = 0; i < invaders.Count(); i++)
            {
                if (BBcoll(Player.Left, Player.Top, Player.Width, Player.Height, invaders[i].box.Left, invaders[i].box.Top, invaders[i].box.Width, invaders[i].box.Height) == true)
                {
                    gameOver = true;
                    Over.Visible = true;
                }
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            
        }



        
    }
}
